import '../models/market_asset.dart';

/// Replace this demo repository with a licensed market-data provider.
///
/// Important:
/// - Do not scrape broker/web chart data without permission.
/// - Forex/CFD prices are provider-specific and may differ between brokers.
/// - Never embed private API keys in the mobile application.
/// - Route authenticated requests through your backend.
abstract class MarketDataService {
  Future<List<MarketAsset>> fetchWatchlist();
}

class DemoMarketDataService implements MarketDataService {
  @override
  Future<List<MarketAsset>> fetchWatchlist() async {
    // Deliberately returns placeholders; no live prices are being fabricated.
    return sampleAssets;
  }
}
