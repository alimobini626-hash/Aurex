class MarketAsset {
  const MarketAsset({
    required this.symbol,
    required this.name,
    required this.category,
    required this.price,
    required this.change,
  });

  final String symbol;
  final String name;
  final String category;
  final String price;
  final double change;

  bool get isPositive => change >= 0;
}

const sampleAssets = <MarketAsset>[
  MarketAsset(symbol: 'XAUUSD', name: 'Gold / US Dollar', category: 'Metals', price: '—', change: 0.0),
  MarketAsset(symbol: 'EURUSD', name: 'Euro / US Dollar', category: 'Forex', price: '—', change: 0.0),
  MarketAsset(symbol: 'BTCUSD', name: 'Bitcoin / US Dollar', category: 'Crypto', price: '—', change: 0.0),
  MarketAsset(symbol: 'ETHUSD', name: 'Ethereum / US Dollar', category: 'Crypto', price: '—', change: 0.0),
  MarketAsset(symbol: 'NASDAQ', name: 'Nasdaq 100', category: 'Indices', price: '—', change: 0.0),
  MarketAsset(symbol: 'XAGUSD', name: 'Silver / US Dollar', category: 'Metals', price: '—', change: 0.0),
];
