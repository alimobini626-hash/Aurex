import 'package:flutter/material.dart';
import 'screens/aurex_shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AurexApp());
}

class AurexApp extends StatelessWidget {
  const AurexApp({super.key});

  @override
  Widget build(BuildContext context) {
    const gold = Color(0xFFD6B36A);
    return MaterialApp(
      title: 'AUREX',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0A0A0B),
        colorScheme: const ColorScheme.dark(
          primary: gold,
          secondary: gold,
          surface: Color(0xFF171719),
          error: Color(0xFFE46C70),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0A0A0B),
          foregroundColor: Colors.white,
          elevation: 0,
          centerTitle: false,
        ),
        dividerColor: const Color(0xFF29282A),
        useMaterial3: true,
      ),
      home: const AurexShell(),
    );
  }
}
