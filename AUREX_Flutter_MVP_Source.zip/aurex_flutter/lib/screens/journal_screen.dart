import 'package:flutter/material.dart';
import '../widgets/aurex_card.dart';

class JournalScreen extends StatefulWidget {
  const JournalScreen({super.key});

  @override
  State<JournalScreen> createState() => _JournalScreenState();
}

class _JournalScreenState extends State<JournalScreen> {
  final _entries = <String>[];

  Future<void> _addEntry() async {
    final controller = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF19191B),
        title: const Text('New journal note'),
        content: TextField(
          controller: controller,
          maxLines: 4,
          decoration: const InputDecoration(hintText: 'Write a note about your trade...'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Save')),
        ],
      ),
    );
    controller.dispose();
    if (result != null && result.isNotEmpty) {
      setState(() => _entries.insert(0, result));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('TRADING JOURNAL', style: TextStyle(color: Color(0xFFD6B36A), letterSpacing: 1.6, fontSize: 11)),
        const SizedBox(height: 5),
        const Text('Your trading log', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
        const SizedBox(height: 16),
        AurexCard(child: Row(children: [
          const Expanded(child: Text('Record your decisions, observations and trade reviews.', style: TextStyle(color: Colors.white60, fontSize: 12, height: 1.5))),
          IconButton(onPressed: _addEntry, icon: const Icon(Icons.add_circle, color: Color(0xFFD6B36A), size: 30)),
        ])),
        const SizedBox(height: 16),
        if (_entries.isEmpty)
          const AurexCard(child: Column(children: [
            Icon(Icons.menu_book_outlined, color: Color(0xFFD6B36A), size: 34),
            SizedBox(height: 10),
            Text('Your journal is empty', style: TextStyle(fontWeight: FontWeight.w700)),
            SizedBox(height: 5),
            Text('Tap + to add your first note.', style: TextStyle(color: Colors.white54, fontSize: 12)),
          ]))
        else
          ..._entries.map((e) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: AurexCard(child: Text(e, style: const TextStyle(height: 1.5))),
          )),
        const SizedBox(height: 8),
        const Text('Prototype note: entries are stored in memory only and will reset when the app closes. Persistent encrypted storage will be added before release.',
          style: TextStyle(color: Colors.white38, fontSize: 11, height: 1.4)),
      ],
    );
  }
}
