import 'package:flutter/material.dart';
import '../models/market_asset.dart';
import '../widgets/aurex_card.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
      children: [
        Row(
          children: [
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('AUREX', style: TextStyle(color: Color(0xFFD6B36A), fontSize: 27, fontWeight: FontWeight.w800, letterSpacing: 3)),
                  SizedBox(height: 2),
                  Text('GLOBAL TRADING PLATFORM', style: TextStyle(color: Color(0xFF9A8B6B), fontSize: 9, letterSpacing: 1.8)),
                ],
              ),
            ),
            IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none, color: Color(0xFFD6B36A))),
          ],
        ),
        const SizedBox(height: 28),
        const Text('MARKET OVERVIEW', style: TextStyle(color: Color(0xFFD6B36A), fontSize: 11, letterSpacing: 1.7)),
        const SizedBox(height: 6),
        const Text('Explore the markets', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w700)),
        const SizedBox(height: 16),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 1.55,
          children: const [
            _MarketTile(icon: Icons.currency_exchange, title: 'FOREX', subtitle: 'Currency pairs'),
            _MarketTile(icon: Icons.monetization_on_outlined, title: 'GOLD & SILVER', subtitle: 'Precious metals'),
            _MarketTile(icon: Icons.currency_bitcoin, title: 'CRYPTO', subtitle: 'Digital assets'),
            _MarketTile(icon: Icons.candlestick_chart, title: 'STOCKS', subtitle: 'Stocks & indices'),
          ],
        ),
        const SizedBox(height: 26),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('WATCHLIST', style: TextStyle(fontWeight: FontWeight.w700, letterSpacing: 1.2)),
            TextButton(onPressed: () {}, child: const Text('VIEW ALL', style: TextStyle(color: Color(0xFFD6B36A), fontSize: 11))),
          ],
        ),
        const AurexCard(
          padding: EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          child: Column(
            children: [
              _AssetRow(asset: sampleAssets[0]),
              Divider(height: 1),
              _AssetRow(asset: sampleAssets[1]),
              Divider(height: 1),
              _AssetRow(asset: sampleAssets[2]),
              Divider(height: 1),
              _AssetRow(asset: sampleAssets[4]),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const AurexCard(
          child: Row(
            children: [
              Icon(Icons.newspaper_outlined, color: Color(0xFFD6B36A), size: 26),
              SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('MARKET NEWS', style: TextStyle(fontWeight: FontWeight.w700, letterSpacing: 1)),
                SizedBox(height: 4),
                Text('Latest market headlines and economic events', style: TextStyle(color: Colors.white60, fontSize: 12)),
              ])),
              Icon(Icons.arrow_forward_ios, size: 14, color: Color(0xFFD6B36A)),
            ],
          ),
        ),
      ],
    );
  }
}

class _MarketTile extends StatelessWidget {
  const _MarketTile({required this.icon, required this.title, required this.subtitle});
  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFF151517),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: const Color(0xFF51432B)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: const Color(0xFFD6B36A), size: 25),
        const SizedBox(height: 10),
        Text(title, style: const TextStyle(color: Color(0xFFE2C681), fontSize: 12, fontWeight: FontWeight.w700)),
        const SizedBox(height: 3),
        Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 10)),
      ]),
    );
  }
}

class _AssetRow extends StatelessWidget {
  const _AssetRow({required this.asset});
  final MarketAsset asset;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 13),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(asset.symbol, style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 3),
          Text(asset.name, style: const TextStyle(color: Colors.white54, fontSize: 11)),
        ])),
        const Text('—', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
      ]),
    );
  }
}
