import 'package:flutter/material.dart';
import '../models/market_asset.dart';
import '../widgets/aurex_card.dart';

class MarketsScreen extends StatefulWidget {
  const MarketsScreen({super.key});

  @override
  State<MarketsScreen> createState() => _MarketsScreenState();
}

class _MarketsScreenState extends State<MarketsScreen> {
  String _filter = 'All';
  final _filters = const ['All', 'Forex', 'Metals', 'Crypto', 'Indices'];

  @override
  Widget build(BuildContext context) {
    final assets = sampleAssets.where((a) => _filter == 'All' || a.category == _filter).toList();
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('MARKETS', style: TextStyle(color: Color(0xFFD6B36A), letterSpacing: 1.8, fontSize: 11)),
        const SizedBox(height: 5),
        const Text('All markets', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w700)),
        const SizedBox(height: 18),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(children: _filters.map((f) => Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ChoiceChip(
              label: Text(f),
              selected: _filter == f,
              onSelected: (_) => setState(() => _filter = f),
              selectedColor: const Color(0xFF4A3A20),
              side: const BorderSide(color: Color(0xFF6A5735)),
            ),
          )).toList()),
        ),
        const SizedBox(height: 16),
        ...assets.map((asset) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: AurexCard(child: Row(children: [
            const Icon(Icons.show_chart, color: Color(0xFFD6B36A)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(asset.symbol, style: const TextStyle(fontWeight: FontWeight.w700)),
              Text(asset.name, style: const TextStyle(color: Colors.white54, fontSize: 11)),
            ])),
            const Text('—', style: TextStyle(color: Colors.white70)),
            const SizedBox(width: 8),
            IconButton(onPressed: () {}, icon: const Icon(Icons.star_border, color: Color(0xFFD6B36A))),
          ])),
        )),
        const Text('Prices are not connected yet. Connect a licensed data provider before showing live quotes.',
          style: TextStyle(color: Colors.white38, fontSize: 11)),
      ],
    );
  }
}
