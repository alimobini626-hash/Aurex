import 'package:flutter/material.dart';
import 'home_screen.dart';
import 'markets_screen.dart';
import 'charts_screen.dart';
import 'news_screen.dart';
import 'journal_screen.dart';

class AurexShell extends StatefulWidget {
  const AurexShell({super.key});

  @override
  State<AurexShell> createState() => _AurexShellState();
}

class _AurexShellState extends State<AurexShell> {
  int _index = 0;

  static const _pages = <Widget>[
    HomeScreen(),
    MarketsScreen(),
    ChartsScreen(),
    NewsScreen(),
    JournalScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _index, children: _pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        backgroundColor: const Color(0xFF111113),
        indicatorColor: const Color(0xFF3B3020),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.public), label: 'بازارها'),
          NavigationDestination(icon: Icon(Icons.candlestick_chart), label: 'نمودار'),
          NavigationDestination(icon: Icon(Icons.newspaper), label: 'اخبار'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'ژورنال'),
        ],
      ),
    );
  }
}
