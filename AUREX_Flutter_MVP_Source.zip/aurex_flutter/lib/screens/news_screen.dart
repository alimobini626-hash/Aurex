import 'package:flutter/material.dart';
import '../widgets/aurex_card.dart';

class NewsScreen extends StatelessWidget {
  const NewsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('MARKET INTELLIGENCE', style: TextStyle(color: Color(0xFFD6B36A), letterSpacing: 1.6, fontSize: 11)),
        const SizedBox(height: 5),
        const Text('News & calendar', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
        const SizedBox(height: 18),
        const AurexCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Icon(Icons.calendar_month, color: Color(0xFFD6B36A)), SizedBox(width: 9), Text('ECONOMIC CALENDAR', style: TextStyle(fontWeight: FontWeight.w700))]),
          SizedBox(height: 10),
          Text('Economic events will appear here after a calendar data provider is connected.', style: TextStyle(color: Colors.white60, fontSize: 12, height: 1.5)),
        ])),
        const SizedBox(height: 14),
        const Text('LATEST HEADLINES', style: TextStyle(color: Color(0xFFD6B36A), letterSpacing: 1.2, fontSize: 11)),
        const SizedBox(height: 10),
        const AurexCard(child: Text('No news feed connected yet. Add a licensed news provider and show source, timestamp and original article link for each item.',
          style: TextStyle(color: Colors.white60, fontSize: 12, height: 1.5))),
      ],
    );
  }
}
