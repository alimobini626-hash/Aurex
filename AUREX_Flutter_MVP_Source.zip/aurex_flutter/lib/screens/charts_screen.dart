import 'package:flutter/material.dart';
import '../widgets/aurex_card.dart';
import '../widgets/market_chart_painter.dart';

class ChartsScreen extends StatefulWidget {
  const ChartsScreen({super.key});

  @override
  State<ChartsScreen> createState() => _ChartsScreenState();
}

class _ChartsScreenState extends State<ChartsScreen> {
  String _symbol = 'XAUUSD';
  String _timeframe = '1H';
  final _symbols = const ['XAUUSD', 'EURUSD', 'BTCUSD', 'ETHUSD', 'XAGUSD', 'NASDAQ'];
  final _frames = const ['1m', '5m', '15m', '1H', '4H', '1D', '1W', '1M'];

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        const Text('AUREX CHARTS', style: TextStyle(color: Color(0xFFD6B36A), letterSpacing: 1.7, fontSize: 11)),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: DropdownButtonFormField<String>(
            value: _symbol,
            decoration: const InputDecoration(labelText: 'Symbol', border: OutlineInputBorder(), contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8)),
            items: _symbols.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
            onChanged: (v) => setState(() => _symbol = v ?? _symbol),
          )),
          const SizedBox(width: 10),
          IconButton(onPressed: () {}, icon: const Icon(Icons.fullscreen, color: Color(0xFFD6B36A))),
          IconButton(onPressed: () {}, icon: const Icon(Icons.tune, color: Color(0xFFD6B36A))),
        ]),
        const SizedBox(height: 12),
        AurexCard(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_symbol, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
            const SizedBox(height: 3),
            const Text('Live quote unavailable · Demo visual only', style: TextStyle(color: Colors.white54, fontSize: 11)),
            const SizedBox(height: 14),
            SizedBox(
              height: 260,
              width: double.infinity,
              child: CustomPaint(painter: const MarketChartPainter()),
            ),
            const SizedBox(height: 12),
            Wrap(spacing: 5, children: _frames.map((f) => ChoiceChip(
              label: Text(f, style: const TextStyle(fontSize: 11)),
              selected: _timeframe == f,
              onSelected: (_) => setState(() => _timeframe = f),
              selectedColor: const Color(0xFF4A3A20),
              side: const BorderSide(color: Color(0xFF6A5735)),
              visualDensity: VisualDensity.compact,
            )).toList()),
          ]),
        ),
        const SizedBox(height: 14),
        const AurexCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('CHART TOOLS', style: TextStyle(color: Color(0xFFD6B36A), fontWeight: FontWeight.w700, letterSpacing: 1)),
          SizedBox(height: 8),
          Text('Drawing tools, indicators, multi-chart layouts, saved templates and real-time streaming are planned for the chart integration phase.',
            style: TextStyle(color: Colors.white60, fontSize: 12, height: 1.5)),
        ])),
      ],
    );
  }
}
