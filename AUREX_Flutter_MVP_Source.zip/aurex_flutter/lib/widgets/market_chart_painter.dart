import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Decorative sample candles for the first UI prototype.
/// This is NOT a live or historically accurate market chart.
class MarketChartPainter extends CustomPainter {
  const MarketChartPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final gridPaint = Paint()
      ..color = const Color(0xFF29282A)
      ..strokeWidth = 0.7;
    for (var i = 1; i < 5; i++) {
      final y = size.height * i / 5;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    final values = <double>[
      .60, .54, .58, .48, .51, .43, .47, .38, .42, .35,
      .39, .31, .36, .28, .32, .24, .29, .21, .25, .18,
    ];
    final candleWidth = size.width / (values.length * 1.8);
    for (var i = 0; i < values.length; i++) {
      final x = (i + .7) * size.width / values.length;
      final open = values[i] * size.height;
      final close = (values[math.min(i + 1, values.length - 1)] +
              (i.isEven ? .025 : -.02)) *
          size.height;
      final rising = close < open;
      final color = rising ? const Color(0xFF40B58A) : const Color(0xFFE16E73);
      final paint = Paint()..color = color;
      final high = math.max(open, close) - size.height * .035;
      final low = math.min(open, close) + size.height * .035;
      canvas.drawLine(Offset(x, high), Offset(x, low), paint..strokeWidth = 1.2);
      final top = math.min(open, close);
      final bodyHeight = math.max(4.0, (open - close).abs());
      canvas.drawRect(
        Rect.fromLTWH(x - candleWidth / 2, top, candleWidth, bodyHeight),
        paint,
      );
    }

    final guide = Paint()
      ..color = const Color(0xFFD6B36A).withOpacity(.65)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;
    final dashY = size.height * .27;
    const dash = 5.0;
    var x = 0.0;
    while (x < size.width) {
      canvas.drawLine(Offset(x, dashY), Offset(x + dash, dashY), guide);
      x += dash * 2;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
