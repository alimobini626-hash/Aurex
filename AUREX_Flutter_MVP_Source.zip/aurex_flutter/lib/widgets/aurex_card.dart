import 'package:flutter/material.dart';

class AurexCard extends StatelessWidget {
  const AurexCard({super.key, required this.child, this.padding = const EdgeInsets.all(16)});

  final Widget child;
  final EdgeInsets padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: const Color(0xFF151517),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF383126)),
      ),
      child: child,
    );
  }
}
