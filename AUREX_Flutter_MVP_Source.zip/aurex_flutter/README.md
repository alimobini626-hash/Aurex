# AUREX — Flutter mobile MVP scaffold

AUREX is a premium dark/black-and-gold multi-market trading companion.

## Included in this first mobile prototype

- Home dashboard
- Market categories: Forex, metals, crypto, stocks/indices
- Market list with category filters
- Chart screen shell with symbol/timeframe selectors and illustrative candle painter
- News and economic calendar placeholder
- Basic journal note entry (in-memory only)
- Bottom navigation

## Important status

This is a **UI and app-structure starter**, not a live trading terminal.
- Prices are deliberately shown as unavailable (`—`); no live market prices are fabricated.
- The sample chart is decorative and is not historical or real-time market data.
- Chart drawing tools, indicators, multi-chart layouts and real-time streaming are not connected.
- News/calendar feeds are not connected.
- Journal notes are currently in-memory only and reset after closing the app.
- No broker or exchange trading is enabled.

## Requirements

- Flutter stable (Dart 3.3+)
- Android Studio or VS Code
- Android SDK / emulator or Android device

## Run

```bash
flutter pub get
flutter run
```

To build an Android APK:

```bash
flutter build apk --release
```

APK output:
`build/app/outputs/flutter-apk/app-release.apk`

## Suggested next engineering milestones

1. Add persistent local journal storage and account backup.
2. Select a licensed market-data provider for each asset class.
3. Implement a backend API; never ship private provider API keys in the app.
4. Integrate a charting SDK/library with the appropriate commercial license.
5. Add watchlist persistence and push/local price alerts.
6. Integrate a licensed news feed and economic calendar.
7. Add tests, crash reporting, privacy policy and security review.
8. Only later evaluate read-only broker connections and, separately, regulated order execution.

## Architecture

`lib/screens` — app pages  
`lib/widgets` — shared UI components and chart placeholder  
`lib/models` — market data models  
`lib/services` — data-provider abstraction

## Brand

Working brand: **AUREX**  
Visual direction: matte black, metallic gold, ivory typography.
The name, domain and trademark availability have not yet been verified.
